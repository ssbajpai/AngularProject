import { Component } from '@angular/core';

@Component({
  selector: 'app-root', // exposed in an element selector
  templateUrl: './app.component.html', // html -- template is mandatory -- should be only one
  styleUrls: ['./app.component.css'] // css -- styles are optional -- can be multiple
})
export class AppComponent {
  // ts
  title = 'contact-mgr-cgi-ng11-jun2021';
}
