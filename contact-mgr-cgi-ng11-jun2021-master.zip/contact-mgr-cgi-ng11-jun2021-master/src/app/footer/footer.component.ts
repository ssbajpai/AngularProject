import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  template: `
    <footer class="text-center">
      <hr />
      <app-menu></app-menu>
      <p class="redText">Copyright - Arun - 2021</p>
    </footer>
  `,
  styles: [
    `
      .redText{
        color: red;
      }
    `
  ]
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
