import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-concepts',
  templateUrl: './concepts.component.html',
  styles: [
  ]
})
export class ConceptsComponent implements OnInit {

  appName = 'Contact Manager App';

  companyName = 'CGI';

  courseName = 'Angular';

  myAge = 25;

  dataReceivedFromChilComp = '';

  isLoggedIn = true;

  skillList: Array<string> = ['angular', 'react', 'nodejs'];

  constructor() { }

  ngOnInit(): void {
  }

  // event binding related
  handleClickMe(event: any): void {
    alert('clicked');
    // TODO: change the button text to 'Clicked'
    // TODO: disable the button
  }

  // Step 6 of CEB: Let's receive the data in event handler
  handleProfileLoaded(event: any): void{
    this.dataReceivedFromChilComp = event;
  }
}
