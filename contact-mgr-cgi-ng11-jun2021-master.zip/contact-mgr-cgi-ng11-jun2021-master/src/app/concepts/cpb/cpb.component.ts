import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpb',
  templateUrl: './cpb.component.html',
  styles: [
  ]
})
export class CpbComponent implements OnInit {

  // Step 1: Let's create a custom property
  @Input() age = 10; // @Input() will make age as custom property to 'app-cpb' selector

  constructor() { }

  ngOnInit(): void {
  }

}
