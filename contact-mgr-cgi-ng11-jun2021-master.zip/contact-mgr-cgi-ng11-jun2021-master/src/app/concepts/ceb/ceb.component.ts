import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-ceb',
  template: `
    <div>
      <button type="button" (click)="handleSendData()">Send Data</button>
    </div>
  `,
  styles: [
  ]
})
export class CebComponent implements OnInit {

  // Step 1: Let's have some data to be sent
  profileName = 'Arun';

  // Step 2: Let's have the an obj for EventEmitter class
  @Output() profileLoaded = new EventEmitter(); // Step 3: Make this as custom event to the selector 'app-ceb' by using @Output()

  constructor() { }

  ngOnInit(): void {
  }

  handleSendData(): void {
    // Step 4: Let's trigger / emit the custom event with the data
    this.profileLoaded.emit(this.profileName);
  }

}
